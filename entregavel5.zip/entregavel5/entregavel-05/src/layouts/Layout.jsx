
import { Outlet } from "react-router-dom";
import Navbar from "../components/Navbar";

function Layout() {
  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />

      <main className="max-w-6xl mx-auto px-6 pt-28 pb-12">
        <Outlet />
      </main>

      <footer className="bg-gray-900 text-white text-center py-6">
        © 2026 - Meu Projeto React
      </footer>
    </div>
  );
}

export default Layout;
