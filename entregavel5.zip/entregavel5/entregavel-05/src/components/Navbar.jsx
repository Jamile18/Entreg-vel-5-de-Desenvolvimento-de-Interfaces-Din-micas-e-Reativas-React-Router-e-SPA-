
import { NavLink } from "react-router-dom";

function Navbar() {
  const linkStyle = ({ isActive }) =>
    `px-4 py-2 rounded-lg transition ${
      isActive
        ? "bg-blue-600 text-white"
        : "text-gray-600 hover:bg-blue-100 hover:text-blue-700"
    }`;

  return (
    <nav className="fixed top-0 left-0 w-full bg-white shadow-md z-50">
      <div className="max-w-6xl mx-auto px-6 py-4 flex flex-wrap justify-between items-center gap-4">
        <h1 className="text-2xl font-bold text-blue-700">
          Meu Projeto
        </h1>

        <div className="flex gap-2">
          <NavLink to="/" end className={linkStyle}>Home</NavLink>
          <NavLink to="/listagem" className={linkStyle}>Listagem</NavLink>
          <NavLink to="/item/1" className={linkStyle}>Detalhes</NavLink>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
