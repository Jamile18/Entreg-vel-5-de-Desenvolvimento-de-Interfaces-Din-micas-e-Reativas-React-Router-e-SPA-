
import { Link } from "react-router-dom";

function Home() {
  return (
    <section className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
      <span className="text-blue-600 font-semibold">BEM-VINDO</span>

      <h2 className="text-4xl font-bold text-gray-800 mt-4 mb-6">
        Minha aplicação React
      </h2>

      <p className="text-gray-600 text-lg leading-relaxed mb-8">
        Este projeto demonstra uma aplicação de página única (SPA),
        utilizando React Router para navegar entre diferentes páginas
        sem recarregar o navegador.
      </p>

      <Link
        to="/listagem"
        className="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700"
      >
        Conhecer a listagem
      </Link>
    </section>
  );
}

export default Home;
