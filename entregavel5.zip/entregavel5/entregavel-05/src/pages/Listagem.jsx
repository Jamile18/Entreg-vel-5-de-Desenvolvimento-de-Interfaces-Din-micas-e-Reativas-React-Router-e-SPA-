
import { Link } from "react-router-dom";

const itens = [
  { id: 1, nome: "Produto 1", descricao: "Primeiro item da lista" },
  { id: 2, nome: "Produto 2", descricao: "Segundo item da lista" },
  { id: 3, nome: "Produto 3", descricao: "Terceiro item da lista" },
];

function Listagem() {
  return (
    <section>
      <h2 className="text-3xl font-bold text-gray-800 mb-3">
        Listagem de itens
      </h2>

      <p className="text-gray-600 mb-8">
        Confira os itens disponíveis e acesse seus detalhes.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {itens.map((item) => (
          <div key={item.id} className="bg-white p-6 rounded-xl shadow-md">
            <h3 className="text-xl font-bold text-gray-800 mb-2">
              {item.nome}
            </h3>

            <p className="text-gray-600 mb-5">{item.descricao}</p>

            <Link
              to={`/item/${item.id}`}
              className="inline-block bg-blue-600 text-white px-5 py-2 rounded-lg hover:bg-blue-700"
            >
              Ver detalhes
            </Link>
          </div>
        ))}
      </div>
    </section>
  );
}

export default Listagem;
