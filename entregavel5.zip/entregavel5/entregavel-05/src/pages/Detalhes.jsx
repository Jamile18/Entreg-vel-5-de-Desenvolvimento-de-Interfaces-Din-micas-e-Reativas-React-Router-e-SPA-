
import { useParams, Link } from "react-router-dom";

function Detalhes() {
  const { id } = useParams();

  return (
    <section className="bg-white rounded-2xl shadow-lg p-8">
      <span className="text-blue-600 font-semibold">
        DETALHES DO ITEM
      </span>

      <h2 className="text-3xl font-bold text-gray-800 mt-4 mb-6">
        Informações do produto
      </h2>

      <div className="bg-blue-50 rounded-xl p-6 mb-6">
        <p className="text-gray-700 text-lg">
          Identificador do item:
        </p>

        <p className="text-4xl font-bold text-blue-700 mt-2">
          #{id}
        </p>
      </div>

      <p className="text-gray-600 mb-8">
        O ID foi capturado diretamente da URL utilizando o hook useParams.
      </p>

      <Link
        to="/listagem"
        className="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700"
      >
        Voltar para listagem
      </Link>
    </section>
  );
}

export default Detalhes;
